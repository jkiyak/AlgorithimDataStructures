public class RedBlackBST<T> extends BinaryTree<T> {


    /**
     * Constructor for initializing a tree with node
     * being set as the root of the tree.
     *
     * @param node
     */

    public void RedBlackBST(BinaryTreeNode node) {

    }

    public void RBInsert(RBNode<T> node){
        node.isRed = true;
        super.insert(node);
        rbInsertFixup(node);
    }
}
