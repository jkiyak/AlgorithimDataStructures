public class RBNode<T,V> extends BinaryTreeNode<T> {
    boolean isRed;
    V value;

    public RBNode (T data, V value) {
        super(data);
        this.value = value;


    }

    public  void leftrotate(RBNode node) {

    }

    public void  rightrotate(RBNode node) {

    }

    private void rbInsertFixup(RBNode node){

    }

}
