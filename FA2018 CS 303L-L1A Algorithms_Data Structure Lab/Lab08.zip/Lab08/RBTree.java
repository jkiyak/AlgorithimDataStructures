
@SuppressWarnings("rawtypes")
public class RBTree<T> extends BinaryTree {

	@SuppressWarnings({ "rawtypes", "unchecked" })
	public RBTree(BinaryTreeNode node) {
		super(node);
		// TODO Auto-generated constructor stub
	}
	
	public void insert(RBNode node) {
		super.insert(node);
		node.isRed = true;
		insertfixup(node);
	}

	private void leftRotate(RBNode node) {
		System.out.println("Shut up");
	}
	private void rightRotate(RBNode node) {
		System.out.println("Shut up");
}
	private void insertfixup(RBNode node) {
		System.out.println("Shut up");

	}
}
